# CSCI 4239 Final Project: PlotComplex

## A graphing calculator for complex functions

The progress I have made so far is not really visual: the main thing I have accomplished is the equation parsing functionality. Enter an equation into the input box and the equation will be parsed into an expression tree using the mathjs library, and displayed on the page using MathJax. The tree is then traversed, and an output array of the expression in Reverse Polish Notation is logged to the console. This array will be sent to the vertex and fragment shaders as uniforms, to be evaluated inside the shaders. Note that very large numbers in the output arrays are reserved constants to signify mathematical operations.

A WebGL instance is running, but currently just rendering a default sphere.

What remains to be completed is the conversion of the two views that I already have written in C to WebGL, and to write a vertex shader for the surface view. I also need to write the functionality to evaluate the Reverse Polish Notation within the shaders.
